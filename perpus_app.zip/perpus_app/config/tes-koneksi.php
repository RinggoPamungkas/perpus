<?php

include 'databases.php';

$database = new Database();
$database->getConnection();

?>